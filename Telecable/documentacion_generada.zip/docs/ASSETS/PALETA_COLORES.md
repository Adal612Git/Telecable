# Paleta de Colores y Estilo

## Paleta
| Token | HEX | Uso sugerido |
|---|---|---|
| primary | #1E88E5 | Botones principales, énfasis |
| secondary | #E53935 | CTAs secundarios, resaltes |
| accent | #FFC107 | Badges, indicadores |
| success | #43A047 | Mensajes de éxito |
| warning | #FB8C00 | Alertas no críticas |
| error | #D32F2F | Errores, validaciones |
| background | #FAFAFA | Fondo general (light) |
| surface | #FFFFFF | Tarjetas y contenedores |
| text_primary | #212121 | Texto principal |
| text_secondary | #616161 | Texto secundario |

## Tipografía
- Inter/Roboto 18–24pt for titles
- Inter/Roboto 12–14pt for body

## Lineamientos rápidos
- Contraste mínimo 4.5:1 para texto principal.
- Tamaño mínimo de fuente 12pt en cuerpos, 18pt en títulos.
- Uso de espacios: 8px grid para paddings y gaps.
- Estados de UI: hover, focus, active con cambios de opacidad 8–16%.
