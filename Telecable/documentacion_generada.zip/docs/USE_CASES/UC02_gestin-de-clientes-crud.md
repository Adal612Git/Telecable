# UC02 – Gestión de clientes (CRUD)

**Actor primario:** Administrador  
**Ámbito:** Backend + DB  
**Nivel:** Sistema  
**Versión del producto:** 1.0.0

## Descripción
MVP de un ERP ligero con módulos de ventas, clientes y autenticación.

## Precondiciones
- Administrador autenticado con permisos.

## Disparador
- El admin accede al módulo 'Clientes'.

## Flujo principal
1. Listar clientes con filtros.
2. Crear nuevo cliente con validaciones.
3. Editar datos de cliente.
4. Eliminar cliente (borrado lógico).

## Flujos alternos
**Validaciones fallidas**
- El sistema rechaza el alta/edición y muestra errores de validación.

## Postcondiciones
- Datos persistidos en DB.
- Eventos de auditoría generados.

## Reglas de negocio
- Email único.
- Borrado lógico para preservar histórico.

## Requisitos no funcionales
- Paginación por rendimiento.
- Índices en campos de búsqueda.

## Criterios de aceptación
- Crear/Editar/Listar/Eliminar con permisos correctos.

## Sugerencias de diseño (patrones)
- Repository
- Unit of Work
- Specification
- DTOs
- Service Layer
- Config via 12-Factor
- Observability (logs/metrics/traces)

## Diagrama de secuencia (Mermaid)
```mermaid
sequenceDiagram
    participant Administrador
    participant SistemaLotusErpMvp
    Note over Administrador,SistemaLotusErpMvp: UC02 – Gestión de clientes (CRUD)
    Administrador->>SistemaLotusErpMvp: Listar clientes con filtros.
    SistemaLotusErpMvp-->>Administrador: Crear nuevo cliente con validaciones.
    Administrador->>SistemaLotusErpMvp: Editar datos de cliente.
    SistemaLotusErpMvp-->>Administrador: Eliminar cliente (borrado lógico).
```
