# UC03 – Registrar venta con pago

**Actor primario:** Usuario  
**Ámbito:** Frontend + API + Pasarela  
**Nivel:** Usuario  
**Versión del producto:** 1.0.0

## Descripción
MVP de un ERP ligero con módulos de ventas, clientes y autenticación.

## Precondiciones
- Usuario autenticado.
- Inventario sincronizado.

## Disparador
- El usuario selecciona productos y procede a pagar.

## Flujo principal
1. Calcular total e impuestos.
2. Seleccionar método de pago.
3. Autorizar pago en pasarela.
4. Registrar venta y generar ticket.

## Flujos alternos
**Pago rechazado**
- La pasarela rechaza el cargo.
- El sistema notifica y permite reintentar o cambiar método.

## Postcondiciones
- Venta registrada.
- Asiento contable opcional.
- Comprobante entregado.

## Reglas de negocio
- IVA 16% MX.
- Devolución en 7 días si aplica política.

## Requisitos no funcionales
- Idempotencia en API de cobro.
- Tiempos de respuesta < 1.5s.

## Criterios de aceptación
- Pago autorizado genera venta y ticket.

## Sugerencias de diseño (patrones)
- Strategy (PaymentMethod)
- Template Method
- Adapter (Gateway SDK)
- Outbox
- Circuit Breaker
- Retry/Idempotency
- Saga (orchestration)
- Transactional Messaging
- Config via 12-Factor
- Observability (logs/metrics/traces)

## Diagrama de secuencia (Mermaid)
```mermaid
sequenceDiagram
    participant Usuario
    participant SistemaLotusErpMvp
    Note over Usuario,SistemaLotusErpMvp: UC03 – Registrar venta con pago
    Usuario->>SistemaLotusErpMvp: Calcular total e impuestos.
    SistemaLotusErpMvp-->>Usuario: Seleccionar método de pago.
    Usuario->>SistemaLotusErpMvp: Autorizar pago en pasarela.
    SistemaLotusErpMvp-->>Usuario: Registrar venta y generar ticket.
```
