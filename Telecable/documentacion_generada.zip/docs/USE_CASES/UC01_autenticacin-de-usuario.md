# UC01 – Autenticación de usuario

**Actor primario:** Usuario  
**Ámbito:** Frontend + API Auth  
**Nivel:** Usuario  
**Versión del producto:** 1.0.0

## Descripción
MVP de un ERP ligero con módulos de ventas, clientes y autenticación.

## Precondiciones
- El usuario está registrado.
- El sistema está en línea.

## Disparador
- El usuario abre la aplicación y selecciona 'Iniciar sesión'.

## Flujo principal
1. El usuario introduce email y contraseña.
2. El sistema valida las credenciales.
3. El sistema genera un JWT y establece la sesión.
4. El usuario accede al dashboard.

## Flujos alternos
**Credenciales inválidas**
- El sistema rechaza el login y muestra mensaje de error.
- El usuario puede reintentar o recuperar contraseña.

## Postcondiciones
- Sesión activa con expiración.
- Registro del evento en auditoría.

## Reglas de negocio
- MFA opcional para roles críticos.
- Bloqueo tras 5 intentos fallidos.

## Requisitos no funcionales
- Tiempo de respuesta < 300ms para validación.
- Disponibilidad 99.5%.

## Criterios de aceptación
- Login correcto con credenciales válidas.
- Error claro en credenciales inválidas.

## Sugerencias de diseño (patrones)
- Strategy
- Adapter
- Decorator (logging)
- Facade (AuthService)
- Config via 12-Factor
- Observability (logs/metrics/traces)

## Diagrama de secuencia (Mermaid)
```mermaid
sequenceDiagram
    participant Usuario
    participant SistemaLotusErpMvp
    Note over Usuario,SistemaLotusErpMvp: UC01 – Autenticación de usuario
    Usuario->>SistemaLotusErpMvp: El usuario introduce email y contraseña.
    SistemaLotusErpMvp-->>Usuario: El sistema valida las credenciales.
    Usuario->>SistemaLotusErpMvp: El sistema genera un JWT y establece la sesión.
    SistemaLotusErpMvp-->>Usuario: El usuario accede al dashboard.
```
