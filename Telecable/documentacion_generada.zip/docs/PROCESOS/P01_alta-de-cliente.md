# P01 – Alta de cliente

**Objetivo:** Registrar un nuevo cliente con validaciones y auditoría.  
**Owner:** Área de Ventas

## Entradas
- Formulario web
- API JSON

## Salidas
- Cliente creado
- Evento de auditoría

## Pasos del proceso
2. Recibir datos de cliente.
3. Validar duplicados (email).
4. Persistir en base de datos (borrado lógico = false).
5. Generar evento de auditoría.
6. Notificar al administrador.

## KPI sugeridos
- Tiempo de alta < 2s
- Tasa de error de validación < 5%

## Diagrama de flujo (Mermaid)
```mermaid
flowchart TD
    %% P01 – Alta de cliente
    S0([Inicio])
    S1[Recibir datos de cliente.]
    S2[Validar duplicados (email).]
    S3[Persistir en base de datos (borrado lógico = false).]
    S4[Generar evento de auditoría.]
    S5[Notificar al administrador.]
    S6([Fin])
    S0 --> S1
    S1 --> S2
    S2 --> S3
    S3 --> S4
    S4 --> S5
    S5 --> S6
```
