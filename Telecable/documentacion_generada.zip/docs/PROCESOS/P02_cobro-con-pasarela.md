# P02 – Cobro con pasarela

**Objetivo:** Cobrar de forma segura y registrar la venta.  
**Owner:** Caja

## Entradas
- Orden de compra
- Método de pago

## Salidas
- Comprobante
- Registro de venta

## Pasos del proceso
2. Recibir orden a cobrar.
3. Calcular totales e impuestos.
4. Enviar cargo a pasarela de pago.
5. Recibir respuesta (aprobado o rechazado).
6. Registrar resultado, emitir ticket y notificar.

## KPI sugeridos
- Tasa de éxito de cobro > 97%
- Tiempo de cobro < 2s

## Diagrama de flujo (Mermaid)
```mermaid
flowchart TD
    %% P02 – Cobro con pasarela
    S0([Inicio])
    S1[Recibir orden a cobrar.]
    S2[Calcular totales e impuestos.]
    S3[Enviar cargo a pasarela de pago.]
    S4[Recibir respuesta (aprobado o rechazado).]
    S5[Registrar resultado, emitir ticket y notificar.]
    S6([Fin])
    S0 --> S1
    S1 --> S2
    S2 --> S3
    S3 --> S4
    S4 --> S5
    S5 --> S6
```
