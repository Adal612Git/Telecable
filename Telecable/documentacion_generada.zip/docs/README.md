# Documentación generada – Sistema Lotus ERP MVP (1.0.0)

Generado: 2025-10-11 14:48

## Contenido
- `MANUAL_DE_CASOS_DE_USO_v1.md`
- `MANUAL_DE_PROCESOS_v1.md`
- `/USE_CASES/*.md` (detalle por caso)
- `/PROCESOS/*.md` (detalle por proceso)
- `/ASSETS/PALETA_COLORES.md`
- `/GUIDELINES/PATRONES_Y_RECOMENDACIONES.md`

Los diagramas están en **Mermaid** dentro de los Markdown (sequenceDiagram y flowchart).
