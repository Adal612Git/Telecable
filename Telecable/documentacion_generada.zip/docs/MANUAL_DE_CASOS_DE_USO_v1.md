# Manual de Casos de Uso – v1

# UC01 – Autenticación de usuario

**Actor primario:** Usuario  
**Ámbito:** Frontend + API Auth  
**Nivel:** Usuario  
**Versión del producto:** 1.0.0

## Descripción
MVP de un ERP ligero con módulos de ventas, clientes y autenticación.

## Precondiciones
- El usuario está registrado.
- El sistema está en línea.

## Disparador
- El usuario abre la aplicación y selecciona 'Iniciar sesión'.

## Flujo principal
1. El usuario introduce email y contraseña.
2. El sistema valida las credenciales.
3. El sistema genera un JWT y establece la sesión.
4. El usuario accede al dashboard.

## Flujos alternos
**Credenciales inválidas**
- El sistema rechaza el login y muestra mensaje de error.
- El usuario puede reintentar o recuperar contraseña.

## Postcondiciones
- Sesión activa con expiración.
- Registro del evento en auditoría.

## Reglas de negocio
- MFA opcional para roles críticos.
- Bloqueo tras 5 intentos fallidos.

## Requisitos no funcionales
- Tiempo de respuesta < 300ms para validación.
- Disponibilidad 99.5%.

## Criterios de aceptación
- Login correcto con credenciales válidas.
- Error claro en credenciales inválidas.

## Sugerencias de diseño (patrones)
- Strategy
- Adapter
- Decorator (logging)
- Facade (AuthService)
- Config via 12-Factor
- Observability (logs/metrics/traces)

## Diagrama de secuencia (Mermaid)
```mermaid
sequenceDiagram
    participant Usuario
    participant SistemaLotusErpMvp
    Note over Usuario,SistemaLotusErpMvp: UC01 – Autenticación de usuario
    Usuario->>SistemaLotusErpMvp: El usuario introduce email y contraseña.
    SistemaLotusErpMvp-->>Usuario: El sistema valida las credenciales.
    Usuario->>SistemaLotusErpMvp: El sistema genera un JWT y establece la sesión.
    SistemaLotusErpMvp-->>Usuario: El usuario accede al dashboard.
```


---

# UC02 – Gestión de clientes (CRUD)

**Actor primario:** Administrador  
**Ámbito:** Backend + DB  
**Nivel:** Sistema  
**Versión del producto:** 1.0.0

## Descripción
MVP de un ERP ligero con módulos de ventas, clientes y autenticación.

## Precondiciones
- Administrador autenticado con permisos.

## Disparador
- El admin accede al módulo 'Clientes'.

## Flujo principal
1. Listar clientes con filtros.
2. Crear nuevo cliente con validaciones.
3. Editar datos de cliente.
4. Eliminar cliente (borrado lógico).

## Flujos alternos
**Validaciones fallidas**
- El sistema rechaza el alta/edición y muestra errores de validación.

## Postcondiciones
- Datos persistidos en DB.
- Eventos de auditoría generados.

## Reglas de negocio
- Email único.
- Borrado lógico para preservar histórico.

## Requisitos no funcionales
- Paginación por rendimiento.
- Índices en campos de búsqueda.

## Criterios de aceptación
- Crear/Editar/Listar/Eliminar con permisos correctos.

## Sugerencias de diseño (patrones)
- Repository
- Unit of Work
- Specification
- DTOs
- Service Layer
- Config via 12-Factor
- Observability (logs/metrics/traces)

## Diagrama de secuencia (Mermaid)
```mermaid
sequenceDiagram
    participant Administrador
    participant SistemaLotusErpMvp
    Note over Administrador,SistemaLotusErpMvp: UC02 – Gestión de clientes (CRUD)
    Administrador->>SistemaLotusErpMvp: Listar clientes con filtros.
    SistemaLotusErpMvp-->>Administrador: Crear nuevo cliente con validaciones.
    Administrador->>SistemaLotusErpMvp: Editar datos de cliente.
    SistemaLotusErpMvp-->>Administrador: Eliminar cliente (borrado lógico).
```


---

# UC03 – Registrar venta con pago

**Actor primario:** Usuario  
**Ámbito:** Frontend + API + Pasarela  
**Nivel:** Usuario  
**Versión del producto:** 1.0.0

## Descripción
MVP de un ERP ligero con módulos de ventas, clientes y autenticación.

## Precondiciones
- Usuario autenticado.
- Inventario sincronizado.

## Disparador
- El usuario selecciona productos y procede a pagar.

## Flujo principal
1. Calcular total e impuestos.
2. Seleccionar método de pago.
3. Autorizar pago en pasarela.
4. Registrar venta y generar ticket.

## Flujos alternos
**Pago rechazado**
- La pasarela rechaza el cargo.
- El sistema notifica y permite reintentar o cambiar método.

## Postcondiciones
- Venta registrada.
- Asiento contable opcional.
- Comprobante entregado.

## Reglas de negocio
- IVA 16% MX.
- Devolución en 7 días si aplica política.

## Requisitos no funcionales
- Idempotencia en API de cobro.
- Tiempos de respuesta < 1.5s.

## Criterios de aceptación
- Pago autorizado genera venta y ticket.

## Sugerencias de diseño (patrones)
- Strategy (PaymentMethod)
- Template Method
- Adapter (Gateway SDK)
- Outbox
- Circuit Breaker
- Retry/Idempotency
- Saga (orchestration)
- Transactional Messaging
- Config via 12-Factor
- Observability (logs/metrics/traces)

## Diagrama de secuencia (Mermaid)
```mermaid
sequenceDiagram
    participant Usuario
    participant SistemaLotusErpMvp
    Note over Usuario,SistemaLotusErpMvp: UC03 – Registrar venta con pago
    Usuario->>SistemaLotusErpMvp: Calcular total e impuestos.
    SistemaLotusErpMvp-->>Usuario: Seleccionar método de pago.
    Usuario->>SistemaLotusErpMvp: Autorizar pago en pasarela.
    SistemaLotusErpMvp-->>Usuario: Registrar venta y generar ticket.
```
