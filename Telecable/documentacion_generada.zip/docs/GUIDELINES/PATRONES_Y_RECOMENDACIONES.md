# Recomendaciones Técnicas y de Calidad

## Arquitectura y patrones
- Separación de capas: API, Dominio, Infraestructura.
- Service Layer + Repository para lógica y acceso a datos.
- DTOs para entrada/salida en endpoints.
- Circuit Breaker y Retry para dependencias externas.
- Idempotencia en endpoints de cobro y creación de recursos.
- Observabilidad: logs estructurados, métricas (latencias/p95), trazas distribuidas.

## Seguridad
- JWT con expiración corta + refresh tokens.
- Hash de contraseñas con bcrypt/argon2.
- Rate limiting y protección CSRF según el caso.
- Validación de entrada (server-side) + sanitización.

## DB y rendimiento
- Índices en campos de búsqueda y foreign keys.
- Paginación en listados largos.
- Migraciones versionadas.
- Estrategia de backups y restauración probada.

## Testing
- Unit tests por servicio y capa de dominio.
- Integration tests para endpoints críticos.
- Contrato con pasarela simulada (sandbox).
- Pruebas de carga para picos esperados.

## DevOps
- Despliegue con Docker y variables de entorno.
- CI/CD con linters, tests y seguridad (SAST/DAST si aplica).
- Feature flags para activación controlada.
